import {test} from 'node:test';
import assert from 'node:assert/strict';
import {passwordHash,verifyPassword,verifyDevice,hash,validUsername,seal,unseal} from '../lib/security.js';
import {SpeechMeter,parseAudio,wav,fallbackSummary} from '../lib/metrics.js';
import {LiveCoach} from '../lib/live.js';
import {WebSocketServer} from 'ws';

test('el secreto del dispositivo se verifica por ID y no permite registros arbitrarios',()=>{
  process.env.DEVICE_SECRETS=JSON.stringify({'test-s3':hash('a'.repeat(64))});
  assert.equal(verifyDevice('test-s3','a'.repeat(64)),true);
  assert.equal(verifyDevice('test-s3','b'.repeat(64)),false);
  assert.equal(verifyDevice('otro','a'.repeat(64)),false);
  assert.equal(verifyDevice('__proto__','a'.repeat(64)),false);
  assert.equal(validUsername('../../admin'),false);
});
test('las contraseñas usan sal y verifican el valor sin almacenarlo en texto',async()=>{
  const password='password-de-prueba-1234';const a=await passwordHash(password),b=await passwordHash(password);
  assert.notEqual(a,b);assert.equal(a.includes(password),false);
  assert.equal(await verifyPassword(password,a),true);assert.equal(await verifyPassword('incorrecta',a),false);
});
test('los registros temporales se cifran y una alteración o cambio de contexto se rechaza',()=>{
  process.env.SESSION_SECRET='test-only-random-master-secret-not-real';
  const encoded=seal('contenido privado','session:a');
  assert.equal(encoded.includes('contenido privado'),false);assert.equal(unseal(encoded,'session:a'),'contenido privado');
  assert.throws(()=>unseal(encoded,'session:b'));
  const bytes=Buffer.from(encoded,'base64url');bytes[30]^=1;assert.throws(()=>unseal(bytes.toString('base64url'),'session:a'));
});
test('el audio exige SID, secuencia y offset exactos; PCM16 sin cabecera WAV',()=>{
  const sid='0123456789abcdef',packet=Buffer.alloc(664);packet.write(sid);packet.writeUInt32LE(320,20);packet.writeUInt32LE(1,16);
  packet.writeInt16LE(-32768,24);
  const pcm=parseAudio(packet,sid,1);assert.equal(pcm.length,640);assert.equal(pcm.readInt16LE(0),-32768);
  assert.throws(()=>parseAudio(packet,sid,0),/Se perdió audio/);
  assert.throws(()=>parseAudio(packet.subarray(1),sid,1));
  assert.throws(()=>parseAudio(packet,'aaaaaaaaaaaaaaaa',1));
  const encoded=wav(pcm);assert.equal(encoded.toString('ascii',0,4),'RIFF');assert.equal(encoded.readUInt32LE(40),640);assert.equal(encoded.readUInt32LE(24),16000);
});
test('las estadísticas usan duración real de audio y no inventan una puntuación',()=>{
  const meter=new SpeechMeter();for(let i=0;i<50;i++)meter.audio(Buffer.alloc(640));
  const m=meter.metrics('Bueno, este tema es es importante, o sea, debemos practicar.');
  assert.equal(m.seconds,1);assert.equal(m.longPauses,1);assert.equal(m.silencePercent,100);
  assert.equal(m.repetitions,1);assert.equal(m.fillerCandidates,3);assert.equal(m.wordsPerMinute,m.words*60);
  assert.match(fallbackSummary(m,'texto'),/no son un resumen generado por IA/);
});
test('GPT-Live utiliza el protocolo Live con PCM16 a 16 kHz y confirma su cierre',async()=>{
  process.env.OPENAI_API_KEY='fake-key-only-for-local-test';
  const received:any[]=[];const wss=new WebSocketServer({port:0,host:'127.0.0.1'});
  await new Promise<void>(r=>wss.once('listening',r));
  wss.on('connection',(ws,request)=>{
    assert.equal(request.headers.authorization,'Bearer fake-key-only-for-local-test');
    ws.on('message',raw=>{const e=JSON.parse(raw.toString());received.push(e);
      if(e.type==='session.start')ws.send(JSON.stringify({type:'session.started'}));
      if(e.type==='session.input_audio.append')ws.send(JSON.stringify({type:'session.input_transcript.delta',delta:'Hola, eh, gracias.'}));
      if(e.type==='session.close')ws.send(JSON.stringify({type:'session.closed',usage:{seconds:1}}));
    });
  });
  const events:any[]=[];const failures:string[]=[];
  const coach=new LiveCoach(e=>events.push(e),e=>failures.push(e),`ws://127.0.0.1:${(wss.address() as any).port}`);
  try{
    await coach.open(true);coach.audio(Buffer.alloc(640));
    coach.cue('Datos de prueba');coach.summarize('Indicadores de prueba');
    assert.equal(await coach.close(),true);
    assert.equal(received[0].session.model,'gpt-live-1');assert.equal(received[0].session.audio.format.rate,16000);
    assert.ok(received.some(e=>e.type==='session.input_audio.append'&&Buffer.from(e.audio,'base64').length===640));
    assert.ok(received.some(e=>e.type==='session.instructions.append'));assert.ok(events.some(e=>e.type==='session.input_transcript.delta'));
    assert.deepEqual(failures,[]);
  }finally{coach.abort();for(const client of wss.clients)client.terminate();await new Promise<void>(r=>wss.close(()=>r()));}
});
