# Contexto de ENSAIA Cloud

Actualizado: 2026-10-26. Este documento permite continuar el proyecto sin exponer secretos.

## Solicitud y resultado

Se creó y desplegó una variante independiente del entrenador ENSAIA para ESP32-S3-DevKitC-1 N16R8 e INMP441. La placa propone usuario y contraseña y se autentica con un secreto individual. Desde la web se controla la captura, se visualizan transcripción y consejos y se consultan estadísticas, resumen y archivos privados.

- Producción: https://ensaia-oratoria.vercel.app
- Proyecto Vercel: `ensaia-oratoria`, equipo `roberto-pro`.
- Proyecto ID: `prj_FiGNtGydC80qufsouPVxwH1V5JeS`.
- Despliegue verificado: `dpl_HbTV37ggeRTJNifrZ6R47dpTrerx`.
- Servidor: Node 24, HTTP y WebSocket nativos de Vercel Fluid, máximo 300 s.
- Modelo: `gpt-live-1`, endpoint `wss://api.openai.com/v1/live/sessions`.
- Redis: `ensaia-data`, gratuito 30 MB, sin persistencia a disco; `redis://`. Valores sensibles cifrados en la aplicación con AES-GCM y nombres de claves mediante HMAC.
- Blob privado: `ensaia-registros`, cuentas e informes/audio duraderos.
- Dispositivo autorizado: `ensaia-s3-01`.

Se eliminó únicamente `ssoProtection` de Vercel después de recibir autorización explícita. ENSAIA conserva su propia autenticación y la verificación del secreto del dispositivo. No modificar otros proyectos ni retirar controles propios de ENSAIA.

## Diseño

No usa MQTT ni laptop como puente en esta variante. `ensaia_esp32s3` y los archivos anteriores permanecen intactos. `firmware/ENSAIA_Cloud` contiene el nuevo sketch. I2S: GPIO4 BCLK, GPIO5 WS, GPIO6 SD, L/R a GND, alimentación 3V3.

PCM16 mono 16 kHz, bloques de 320 muestras/20 ms. Cada paquete WSS tiene 664 bytes: SID hexadecimal ASCII de 16 bytes, secuencia uint32 little-endian, desplazamiento en muestras uint32 little-endian y 640 bytes PCM. Se comprueban secuencia, SID, offset, total y confirmación final. El dispositivo recibe ACK cada 20 tramas. Los errores marcan la presentación como interrumpida.

El dispositivo genera credenciales y las guarda en NVS; solo se registran tras validar el secreto. No borrar NVS tras el primer registro. El servidor conserva la asociación y no acepta un reemplazo automático de contraseña. No existe todavía recuperación desde la web.

La interfaz consulta la API autenticada y muestra estado/estadísticas cada pocos segundos. Los mensajes de IA y las transcripciones se tratan como texto sin HTML. El WAV y el JSON se descargan desde rutas que comprueban propiedad. Las recomendaciones son textuales; no se ha implementado altavoz.

## Archivos clave

- `api/server.ts`: rutas HTTP, cookie, control de sesión y upgrade WS.
- `lib/device.ts`: autenticación, comandos y ciclo de captura/archivo.
- `lib/live.ts`: protocolo Live de OpenAI y resumen.
- `lib/store.ts`: coordinación Redis y archivos Blob privados.
- `lib/security.ts`: scrypt, verificación constante, AES-GCM, HMAC.
- `lib/metrics.ts`: indicadores exploratorios y formato WAV.
- `src/main.ts`, `src/style.css`: interfaz en español.
- `firmware/ENSAIA_Cloud/*`: programa Arduino IDE, configuración y autoridades TLS.
- `README.md`: puesta en marcha, cableado, límites y mantenimiento.
- `VERIFICACION.md`: evidencia y alcance real de las pruebas.

Las importaciones relativas TypeScript llevan extensión `.js` para funcionar en el runtime ESM de producción. La primera versión sin esta extensión falló al arrancar; se corrigió, se volvió a desplegar y se verificó health 200 y acceso privado 401.

## Secretos

Nunca imprimir ni publicar `.env.local`, `.private/provision.json` ni `firmware/ENSAIA_Cloud/secrets.h`. La clave OpenAI fue configurada en Vercel; no está en el navegador ni en el ESP32. El usuario la pegó en el chat, por lo que debe rotarla. El ZIP privado del firmware incluye únicamente su secreto individual del dispositivo, sin claves maestras ni API key. El ZIP general de fuente excluye todos los secretos.

## Pendiente presencial

El firmware compila con Arduino-ESP32 3.3.5, WebSockets 2.7.2 y ArduinoJson 6.21.5. Falta introducir Wi-Fi, cargarlo en la placa real y verificar señal/ganancia y una sesión hablada completa. No describir las pruebas simuladas como grabaciones humanas o evidencia de mejora de oratoria.

En los datos anteriores del artículo, D001–D010 corresponden a David, una persona. Leyó guiones antes y después, y consultó recomendaciones IA **antes de iniciar** la lectura posterior. No inferir diez participantes ni retroactividad del feedback en vivo de esta versión.
