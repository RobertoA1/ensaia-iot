#pragma once

// Editar SOLO secrets.h. Nunca pegar la clave de OpenAI en la placa.
static const char WIFI_SSID[] = "IoT-oratoria";
static const char WIFI_PASSWORD[] = "granNobita";
static const char MQTT_HOST[] = "127.0.0.1"; // IPv4 de la laptop
static const uint16_t MQTT_PORT = 1883;
static const char MQTT_USER[] = "oratoria";
static const char MQTT_PASSWORD[] = "jpncXYWwV7EQ_H6sj956zNsK4-8v2xjS";
static const char DEVICE_ID[] = "esp8266-oratoria";
// No se presupone un LED conectado al ESP en esta placa combinada.
static const int STATUS_LED_GPIO = -1;
